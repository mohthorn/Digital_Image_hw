usage: ./pr01 'filename' 'method' 'color_levels'

Usable Commands:
./pr01 02.PPM floyd 5(any number between 1-255)
./pr01 02.PPM ordered 5(any number between 1-255)