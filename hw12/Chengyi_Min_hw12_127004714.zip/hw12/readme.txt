usage:

./pr01 02.PPM NM.ppm SM.ppm depth.ppm