./pr01 'filename' 'filter' 'kernel size'

filter can be:
blur
edge
laplacian
emboss
erosion
dilation

kernel size can only be odd numbers, kernels are only implemented to be squares