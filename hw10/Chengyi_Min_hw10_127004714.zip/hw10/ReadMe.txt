2 seperated programs.

For carving:

usage: ./pr01 'filename' 'method' 'cropped column number'

example:

./pr01 Republic.PPM seam 100

For stiching:

usage: ./pr01 'filename' 'filename''start' 'finish'

Example:

./pr01 Tiananmen.PPM Forbidden_City.PPM 300 500