Run
./pr01 02.PPM NM.ppm SM.ppm
The program will probably crash due to bad memory allocation